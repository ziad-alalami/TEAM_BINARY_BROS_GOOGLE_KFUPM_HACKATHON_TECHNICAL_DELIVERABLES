
  # Simulation Dashboard Design

  This is a code bundle for Simulation Dashboard Design. The original project is available at https://www.figma.com/design/JICBmn5KltwXJ0RrMlcMeF/Simulation-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  