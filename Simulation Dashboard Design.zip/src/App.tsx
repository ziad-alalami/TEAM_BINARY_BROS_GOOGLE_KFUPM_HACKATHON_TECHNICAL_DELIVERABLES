import { useState, useEffect, useRef } from 'react';
import { LeftPanel } from './components/LeftPanel';
import { MapView } from './components/MapView';
import { RightPanel } from './components/RightPanel';
import { SimulationControls } from './components/SimulationControls';
import { SimulationState, District } from './types/simulation';
import { initialState, simulateDay, generateAlerts, getAIResponse } from './lib/simulation';
import exampleImage from 'figma:asset/fee360e811faf3b1a7c1583dd440b1b6e0eadf8e.png';
import { Activity } from 'lucide-react';

export default function App() {
  const [state, setState] = useState<SimulationState>(initialState);
  const [selectedDistrict, setSelectedDistrict] = useState<District | null>(state.districts[0]);
  const simulationInterval = useRef<NodeJS.Timeout | null>(null);

  const MAX_DAYS = 30;

  // Calculate totals
  const totalInfected = Math.round(
    state.districts.reduce((sum, d) => sum + d.infected, 0)
  );
  const totalRecovered = Math.round(
    state.districts.reduce((sum, d) => sum + d.recovered, 0)
  );
  const totalDeaths = Math.round(
    state.districts.reduce((sum, d) => sum + d.deaths, 0)
  );

  // Simulation loop
  useEffect(() => {
    if (state.isPlaying && state.day < MAX_DAYS) {
      simulationInterval.current = setInterval(() => {
        setState((prevState) => {
          const newDistricts = simulateDay(
            prevState.districts,
            prevState.parameters,
            prevState.day
          );
          const newAlerts = generateAlerts(
            newDistricts,
            prevState.parameters,
            prevState.day + 1
          );

          const newDay = prevState.day + 1;

          // Update selected district if it exists
          if (selectedDistrict) {
            const updatedSelected = newDistricts.find(
              (d) => d.id === selectedDistrict.id
            );
            if (updatedSelected) {
              setSelectedDistrict(updatedSelected);
            }
          }

          // Stop if reached max days
          if (newDay >= MAX_DAYS) {
            return {
              ...prevState,
              day: newDay,
              districts: newDistricts,
              alerts: newAlerts,
              isPlaying: false,
            };
          }

          return {
            ...prevState,
            day: newDay,
            districts: newDistricts,
            alerts: newAlerts,
          };
        });
      }, 1000); // 1 second per day

      return () => {
        if (simulationInterval.current) {
          clearInterval(simulationInterval.current);
        }
      };
    }
  }, [state.isPlaying, state.day, selectedDistrict]);

  const handlePlayPause = () => {
    setState((prev) => ({ ...prev, isPlaying: !prev.isPlaying }));
  };

  const handleReset = () => {
    setState(initialState);
    setSelectedDistrict(initialState.districts[0]);
  };

  const handleSimulateFromHere = () => {
    // Run a fast-forward simulation
    setState((prev) => ({ ...prev, isPlaying: true }));
  };

  const handleParametersChange = (newParams: typeof state.parameters) => {
    setState((prev) => ({ ...prev, parameters: newParams }));
  };

  const handleAskAssistant = (message: string): string => {
    return getAIResponse(message, state);
  };

  const handleDistrictSelect = (district: District) => {
    setSelectedDistrict(district);
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 text-white overflow-hidden">
      {/* Header */}
      <header className="flex items-center justify-between px-6 py-4 bg-slate-900/80 backdrop-blur-sm border-b border-slate-700/50">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <Activity className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-white">
              EpidemicSim <span className="text-blue-400">Pro</span>
            </h1>
            <p className="text-slate-400 text-sm">
              Google KFUPM Hackathon | Team Binary Bros
            </p>
          </div>
        </div>

        <div className="flex items-center gap-8">
          <div className="flex flex-col items-end">
            <span className="text-slate-400 text-xs uppercase tracking-wider">
              Total Infected
            </span>
            <span className="text-red-400">{totalInfected.toLocaleString()}</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-slate-400 text-xs uppercase tracking-wider">
              Recovered
            </span>
            <span className="text-green-400">{totalRecovered.toLocaleString()}</span>
          </div>
          <div className="flex flex-col items-end">
            <span className="text-slate-400 text-xs uppercase tracking-wider">Deaths</span>
            <span className="text-slate-300">{totalDeaths.toLocaleString()}</span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Panel */}
        <div className="w-[320px] flex-shrink-0">
          <LeftPanel
            selectedDistrict={selectedDistrict}
            districts={state.districts}
            alerts={state.alerts}
            onDistrictSelect={handleDistrictSelect}
          />
        </div>

        {/* Center Map */}
        <div className="flex-1 relative">
          <MapView
            districts={state.districts}
            selectedDistrict={selectedDistrict}
            onDistrictSelect={handleDistrictSelect}
          />

          {/* Simulation Controls */}
          <SimulationControls
            day={state.day}
            maxDays={MAX_DAYS}
            isPlaying={state.isPlaying}
            totalInfected={totalInfected}
            totalRecovered={totalRecovered}
            totalDeaths={totalDeaths}
            onPlayPause={handlePlayPause}
            onReset={handleReset}
            onSimulateFromHere={handleSimulateFromHere}
          />
        </div>

        {/* Right Panel */}
        <div className="w-[360px] flex-shrink-0">
          <RightPanel
            parameters={state.parameters}
            onParametersChange={handleParametersChange}
            onAskAssistant={handleAskAssistant}
          />
        </div>
      </div>
    </div>
  );
}
