import { District, Alert } from '../types/simulation';
import { AlertTriangle, AlertCircle, Info } from 'lucide-react';

interface LeftPanelProps {
  selectedDistrict: District | null;
  districts: District[];
  alerts: Alert[];
  onDistrictSelect: (district: District) => void;
}

export function LeftPanel({ selectedDistrict, districts, alerts, onDistrictSelect }: LeftPanelProps) {
  const getRiskBadgeColor = (level: string) => {
    switch (level) {
      case 'high':
        return 'bg-red-500/20 text-red-400 border border-red-500/30';
      case 'emerging':
        return 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30';
      case 'stable':
        return 'bg-blue-500/20 text-blue-400 border border-blue-500/30';
      case 'low':
        return 'bg-green-500/20 text-green-400 border border-green-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border border-gray-500/30';
    }
  };

  const getRiskBarColor = (level: string) => {
    switch (level) {
      case 'high':
        return 'bg-red-500';
      case 'emerging':
        return 'bg-yellow-500';
      case 'stable':
        return 'bg-blue-500';
      case 'low':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'critical':
        return <AlertTriangle className="w-4 h-4" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4" />;
      default:
        return <Info className="w-4 h-4" />;
    }
  };

  const district = selectedDistrict || districts[0];

  return (
    <div className="h-full flex flex-col bg-slate-900/50 backdrop-blur-sm border-r border-slate-700/50 overflow-hidden">
      <div className="p-6 border-b border-slate-700/50">
        <h2 className="text-slate-400 uppercase tracking-wider mb-4">District Details</h2>
        
        {/* Main District Card */}
        <div className="bg-slate-800/50 rounded-lg p-5 border border-slate-700/30 mb-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-white">{district.name}</h3>
            <span className={`px-3 py-1 rounded-full text-xs uppercase tracking-wide ${getRiskBadgeColor(district.riskLevel)}`}>
              {district.riskLevel === 'high' ? 'High Risk' : district.riskLevel === 'emerging' ? 'Emerging' : district.riskLevel === 'stable' ? 'Medium' : 'Low Risk'}
            </span>
          </div>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Infection Rate</span>
              <span className="text-white">{district.infectionRate.toFixed(1)}%</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-400">Population</span>
              <span className="text-white">{district.population.toLocaleString()}</span>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-slate-400">Virality Score</span>
              <span className="text-blue-400">{district.viralityScore.toFixed(2)}</span>
            </div>

            <div className="w-full h-1 bg-slate-700 rounded-full overflow-hidden mt-2">
              <div 
                className={`h-full ${getRiskBarColor(district.riskLevel)} transition-all duration-500`}
                style={{ width: `${Math.min(100, district.infectionRate * 5)}%` }}
              />
            </div>

            <p className="text-slate-300 text-sm pt-2 italic">
              {district.status}
            </p>
          </div>
        </div>

        {/* Other Districts */}
        <div className="space-y-2 max-h-[240px] overflow-y-auto scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-transparent">
          {districts
            .filter(d => d.id !== district.id)
            .map((d) => (
              <div
                key={d.id}
                onClick={() => onDistrictSelect(d)}
                className="bg-slate-800/30 rounded-lg p-3 border border-slate-700/20 hover:border-slate-600/50 cursor-pointer transition-all hover:bg-slate-800/50"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white text-sm">{d.name}</span>
                  <span className={`px-2 py-0.5 rounded text-xs ${getRiskBadgeColor(d.riskLevel)}`}>
                    {d.riskLevel === 'high' ? 'High' : d.riskLevel === 'emerging' ? 'Emerging' : d.riskLevel === 'stable' ? 'Medium' : 'Low'}
                  </span>
                </div>
                <div className="w-full h-1 bg-slate-700 rounded-full overflow-hidden">
                  <div 
                    className={`h-full ${getRiskBarColor(d.riskLevel)} transition-all duration-500`}
                    style={{ width: `${Math.min(100, d.infectionRate * 5)}%` }}
                  />
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Live Alerts */}
      <div className="p-6 flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-transparent">
        <h2 className="text-slate-400 uppercase tracking-wider mb-4">Live Alerts</h2>
        
        <div className="space-y-3">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`p-4 rounded-lg border ${
                alert.severity === 'critical'
                  ? 'bg-red-500/10 border-red-500/30'
                  : alert.severity === 'warning'
                  ? 'bg-yellow-500/10 border-yellow-500/30'
                  : 'bg-blue-500/10 border-blue-500/30'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`mt-0.5 ${
                  alert.severity === 'critical'
                    ? 'text-red-400'
                    : alert.severity === 'warning'
                    ? 'text-yellow-400'
                    : 'text-blue-400'
                }`}>
                  {getAlertIcon(alert.severity)}
                </div>
                <p className="text-slate-200 text-sm flex-1">
                  {alert.message}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
