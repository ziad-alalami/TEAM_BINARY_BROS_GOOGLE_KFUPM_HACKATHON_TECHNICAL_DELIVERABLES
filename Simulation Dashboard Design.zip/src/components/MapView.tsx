import { useRef, useEffect, useState } from 'react';
import { District } from '../types/simulation';
import { getRiskColor } from '../lib/simulation';
import saudiMap from 'figma:asset/6f72c8caf7100e62f7cb7701128ca670e438383e.png';

interface MapViewProps {
  districts: District[];
  selectedDistrict: District | null;
  onDistrictSelect: (district: District) => void;
}

export function MapView({ districts, selectedDistrict, onDistrictSelect }: MapViewProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hoveredDistrict, setHoveredDistrict] = useState<District | null>(null);
  const [transform, setTransform] = useState({ x: 0, y: 0, scale: 1 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [mapLoaded, setMapLoaded] = useState(false);
  const mapImageRef = useRef<HTMLImageElement | null>(null);

  // Load map image
  useEffect(() => {
    const img = new Image();
    img.src = saudiMap;
    img.onload = () => {
      mapImageRef.current = img;
      setMapLoaded(true);
    };
    img.onerror = () => {
      // Fallback - just set as loaded to show the canvas
      setMapLoaded(true);
    };
  }, []);

  // Draw the map
  useEffect(() => {
    if (!mapLoaded) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    
    ctx.scale(dpr, dpr);
    canvas.style.width = rect.width + 'px';
    canvas.style.height = rect.height + 'px';

    // Clear canvas with dark background
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, rect.width, rect.height);

    // Apply transform
    ctx.save();
    ctx.translate(transform.x, transform.y);
    ctx.scale(transform.scale, transform.scale);

    // Draw map image if available - fill the entire canvas
    if (mapImageRef.current) {
      ctx.globalAlpha = 0.85;
      const mapWidth = rect.width;
      const mapHeight = rect.height;
      ctx.drawImage(mapImageRef.current, 0, 0, mapWidth, mapHeight);
      ctx.globalAlpha = 1;
    } else {
      // Draw a simple map outline if image fails to load
      ctx.strokeStyle = 'rgba(100, 116, 139, 0.3)';
      ctx.lineWidth = 2;
      ctx.strokeRect(100, 50, 700, 500);
    }

    // Draw connections between nearby districts
    ctx.strokeStyle = 'rgba(100, 116, 139, 0.4)';
    ctx.lineWidth = 3;
    ctx.setLineDash([5, 5]);
    districts.forEach((district1, i) => {
      districts.slice(i + 1).forEach((district2) => {
        const dx = district2.position.x - district1.position.x;
        const dy = district2.position.y - district1.position.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 200) {
          ctx.beginPath();
          ctx.moveTo(district1.position.x, district1.position.y);
          ctx.lineTo(district2.position.x, district2.position.y);
          ctx.stroke();
        }
      });
    });
    ctx.setLineDash([]);

    // Draw districts
    districts.forEach((district) => {
      const isSelected = selectedDistrict?.id === district.id;
      const isHovered = hoveredDistrict?.id === district.id;
      const radius = isSelected ? 24 : isHovered ? 22 : 20;
      
      // Glow effect for selected/hovered
      if (isSelected || isHovered) {
        const gradient = ctx.createRadialGradient(
          district.position.x,
          district.position.y,
          0,
          district.position.x,
          district.position.y,
          radius * 3
        );
        gradient.addColorStop(0, getRiskColor(district.riskLevel) + '80');
        gradient.addColorStop(1, 'transparent');
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(district.position.x, district.position.y, radius * 3, 0, Math.PI * 2);
        ctx.fill();
      }

      // Outer ring with shadow
      ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
      ctx.shadowBlur = 10;
      ctx.strokeStyle = getRiskColor(district.riskLevel);
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.arc(district.position.x, district.position.y, radius + 5, 0, Math.PI * 2);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Node circle
      ctx.fillStyle = getRiskColor(district.riskLevel);
      ctx.beginPath();
      ctx.arc(district.position.x, district.position.y, radius, 0, Math.PI * 2);
      ctx.fill();

      // Inner highlight
      const highlightGradient = ctx.createRadialGradient(
        district.position.x - radius * 0.3,
        district.position.y - radius * 0.3,
        0,
        district.position.x,
        district.position.y,
        radius
      );
      highlightGradient.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
      highlightGradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = highlightGradient;
      ctx.beginPath();
      ctx.arc(district.position.x, district.position.y, radius, 0, Math.PI * 2);
      ctx.fill();

      // Pulsing ring animation for high risk
      if (district.riskLevel === 'high') {
        const pulseRadius = radius + 8 + Math.sin(Date.now() / 300) * 3;
        ctx.strokeStyle = getRiskColor(district.riskLevel) + '60';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(district.position.x, district.position.y, pulseRadius, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Draw district name with background
      ctx.font = 'bold 15px sans-serif';
      ctx.textAlign = 'center';
      const textY = district.position.y + radius + 30;
      
      // Text background
      const textMetrics = ctx.measureText(district.name);
      const textWidth = textMetrics.width;
      const padding = 8;
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.fillRect(
        district.position.x - textWidth / 2 - padding,
        textY - 16,
        textWidth + padding * 2,
        24
      );
      
      // Text with shadow
      ctx.shadowColor = 'rgba(0, 0, 0, 0.8)';
      ctx.shadowBlur = 6;
      ctx.fillStyle = 'white';
      ctx.fillText(district.name, district.position.x, textY);
      ctx.shadowBlur = 0;
    });

    ctx.restore();
  }, [districts, selectedDistrict, hoveredDistrict, transform, mapLoaded]);

  // Handle mouse events
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - transform.x, y: e.clientY - transform.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left - transform.x) / transform.scale;
    const y = (e.clientY - rect.top - transform.y) / transform.scale;

    if (isDragging) {
      setTransform({
        ...transform,
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    } else {
      // Check for hover
      let found = false;
      for (const district of districts) {
        const dx = x - district.position.x;
        const dy = y - district.position.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 30) {
          setHoveredDistrict(district);
          canvas.style.cursor = 'pointer';
          found = true;
          break;
        }
      }
      
      if (!found) {
        setHoveredDistrict(null);
        canvas.style.cursor = isDragging ? 'grabbing' : 'grab';
      }
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleClick = (e: React.MouseEvent) => {
    if (isDragging) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left - transform.x) / transform.scale;
    const y = (e.clientY - rect.top - transform.y) / transform.scale;

    for (const district of districts) {
      const dx = x - district.position.x;
      const dy = y - district.position.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance < 30) {
        onDistrictSelect(district);
        break;
      }
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    const newScale = Math.max(0.5, Math.min(3, transform.scale * delta));
    
    setTransform({
      ...transform,
      scale: newScale,
    });
  };

  return (
    <div ref={containerRef} className="relative w-full h-full bg-slate-950">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onClick={handleClick}
        onWheel={handleWheel}
      />
      
      {/* Hover tooltip */}
      {hoveredDistrict && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 bg-slate-800/95 backdrop-blur-sm border border-slate-700 rounded-lg px-5 py-3 pointer-events-none shadow-xl z-10">
          <div className="text-white mb-1">{hoveredDistrict.name}</div>
          <div className="flex items-center gap-4 text-sm">
            <div className="text-slate-400">
              Infection: <span className="text-white">{hoveredDistrict.infectionRate.toFixed(1)}%</span>
            </div>
            <div className="text-slate-400">
              Risk: <span className={`capitalize ${
                hoveredDistrict.riskLevel === 'high' ? 'text-red-400' :
                hoveredDistrict.riskLevel === 'emerging' ? 'text-yellow-400' :
                hoveredDistrict.riskLevel === 'stable' ? 'text-blue-400' : 'text-green-400'
              }`}>{hoveredDistrict.riskLevel}</span>
            </div>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="absolute bottom-4 left-4 bg-slate-800/90 backdrop-blur-sm border border-slate-700 rounded-lg p-4 shadow-xl">
        <div className="text-slate-300 mb-3">Risk Levels</div>
        <div className="space-y-2">
          <div className="flex items-center gap-3">
            <div className="w-4 h-4 rounded-full bg-green-500 ring-2 ring-green-500/50" />
            <span className="text-slate-400 text-sm">Low Risk</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-4 h-4 rounded-full bg-blue-500 ring-2 ring-blue-500/50" />
            <span className="text-slate-400 text-sm">Stable</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-4 h-4 rounded-full bg-yellow-500 ring-2 ring-yellow-500/50" />
            <span className="text-slate-400 text-sm">Emerging</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-4 h-4 rounded-full bg-red-500 ring-2 ring-red-500/50 animate-pulse" />
            <span className="text-slate-400 text-sm">High Risk</span>
          </div>
        </div>
      </div>

      {/* Controls hint */}
      <div className="absolute top-4 right-4 bg-slate-800/90 backdrop-blur-sm border border-slate-700 rounded-lg px-4 py-2 shadow-xl">
        <div className="text-slate-400 text-sm">
          🖱️ Drag to pan • 🔍 Scroll to zoom • 👆 Click nodes
        </div>
      </div>
    </div>
  );
}