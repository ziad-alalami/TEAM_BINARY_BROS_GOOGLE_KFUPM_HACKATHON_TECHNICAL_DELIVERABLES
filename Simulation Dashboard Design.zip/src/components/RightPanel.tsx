import { useState, useRef, useEffect } from 'react';
import { SimulationParameters, ChatMessage } from '../types/simulation';
import { Send, ChevronDown, ChevronUp, Lock, ShieldCheck, Plane, School, Briefcase, Settings } from 'lucide-react';

interface RightPanelProps {
  parameters: SimulationParameters;
  onParametersChange: (params: SimulationParameters) => void;
  onAskAssistant: (message: string) => string;
}

export function RightPanel({ parameters, onParametersChange, onAskAssistant }: RightPanelProps) {
  const [assistantExpanded, setAssistantExpanded] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Agent. Ask me to run a simulation or explain the current outbreak status.',
      timestamp: Date.now(),
    },
  ]);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages]);

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue,
      timestamp: Date.now(),
    };

    setChatMessages([...chatMessages, userMessage]);

    // Get AI response
    const response = onAskAssistant(inputValue);
    
    setTimeout(() => {
      const assistantMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response,
        timestamp: Date.now(),
      };
      setChatMessages(prev => [...prev, assistantMessage]);
    }, 500);

    setInputValue('');
  };

  const quickActions = [
    'Explain outbreak status',
    'Ask about closing schools',
    'Show 7-day forecast',
    'Explain R0 impact',
  ];

  const handleQuickAction = (action: string) => {
    setInputValue(action);
  };

  return (
    <div className="h-full flex flex-col bg-slate-900/50 backdrop-blur-sm border-l border-slate-700/50 overflow-hidden">
      {/* Simulation Parameters */}
      <div className="p-6 border-b border-slate-700/50 overflow-y-auto scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-transparent">
        <div className="flex items-center gap-2 mb-6">
          <Settings className="w-5 h-5 text-slate-400" />
          <h2 className="text-slate-400 uppercase tracking-wider">Simulation Parameters</h2>
        </div>

        {/* R0 Slider */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-3">
            <label className="text-white">Basic Reproduction (R0)</label>
            <span className="text-blue-400">{parameters.r0.toFixed(1)}</span>
          </div>
          <input
            type="range"
            min="0.5"
            max="5"
            step="0.1"
            value={parameters.r0}
            onChange={(e) =>
              onParametersChange({ ...parameters, r0: parseFloat(e.target.value) })
            }
            className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer slider"
          />
          <p className="text-slate-400 text-sm mt-2">
            Avg number of secondary infections per case.
          </p>
        </div>

        {/* Intervention Policies */}
        <div>
          <h3 className="text-slate-300 mb-4 uppercase tracking-wider text-sm">
            Intervention Policies
          </h3>

          <div className="space-y-3">
            {/* City Lockdown */}
            <div className="flex items-center justify-between p-3 bg-slate-800/40 rounded-lg border border-slate-700/30">
              <div className="flex items-center gap-3">
                <Lock className="w-5 h-5 text-slate-400" />
                <span className="text-white">City Lockdown</span>
              </div>
              <button
                onClick={() =>
                  onParametersChange({
                    ...parameters,
                    cityLockdown: !parameters.cityLockdown,
                  })
                }
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  parameters.cityLockdown ? 'bg-blue-500' : 'bg-slate-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    parameters.cityLockdown ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Mask Mandate */}
            <div className="flex items-center justify-between p-3 bg-slate-800/40 rounded-lg border border-slate-700/30">
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-5 h-5 text-slate-400" />
                <span className="text-white">Mask Mandate</span>
              </div>
              <button
                onClick={() =>
                  onParametersChange({
                    ...parameters,
                    maskMandate: !parameters.maskMandate,
                  })
                }
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  parameters.maskMandate ? 'bg-blue-500' : 'bg-slate-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    parameters.maskMandate ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Travel Reduction */}
            <div className="flex items-center justify-between p-3 bg-slate-800/40 rounded-lg border border-slate-700/30">
              <div className="flex items-center gap-3">
                <Plane className="w-5 h-5 text-slate-400" />
                <span className="text-white">Travel Reduction</span>
              </div>
              <button
                onClick={() =>
                  onParametersChange({
                    ...parameters,
                    travelReduction: !parameters.travelReduction,
                  })
                }
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  parameters.travelReduction ? 'bg-blue-500' : 'bg-slate-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    parameters.travelReduction ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* School Closure */}
            <div className="flex items-center justify-between p-3 bg-slate-800/40 rounded-lg border border-slate-700/30">
              <div className="flex items-center gap-3">
                <School className="w-5 h-5 text-slate-400" />
                <span className="text-white">School Closure</span>
              </div>
              <button
                onClick={() =>
                  onParametersChange({
                    ...parameters,
                    schoolClosure: !parameters.schoolClosure,
                  })
                }
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  parameters.schoolClosure ? 'bg-blue-500' : 'bg-slate-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    parameters.schoolClosure ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {/* Remote Work */}
            <div className="flex items-center justify-between p-3 bg-slate-800/40 rounded-lg border border-slate-700/30">
              <div className="flex items-center gap-3">
                <Briefcase className="w-5 h-5 text-slate-400" />
                <span className="text-white">Remote Work</span>
              </div>
              <button
                onClick={() =>
                  onParametersChange({
                    ...parameters,
                    remoteWork: !parameters.remoteWork,
                  })
                }
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  parameters.remoteWork ? 'bg-blue-500' : 'bg-slate-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    parameters.remoteWork ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Vertex AI Assistant */}
      <div className="flex-1 flex flex-col bg-slate-800/30 border-t border-slate-700/50">
        <button
          onClick={() => setAssistantExpanded(!assistantExpanded)}
          className="flex items-center justify-between p-4 hover:bg-slate-800/50 transition-colors"
        >
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
            <span className="text-white">Vertex AI Assistant</span>
          </div>
          {assistantExpanded ? (
            <ChevronDown className="w-5 h-5 text-slate-400" />
          ) : (
            <ChevronUp className="w-5 h-5 text-slate-400" />
          )}
        </button>

        {assistantExpanded && (
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin scrollbar-thumb-slate-600 scrollbar-track-transparent">
              {chatMessages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-lg p-3 ${
                      message.role === 'user'
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-700/50 text-slate-200'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Quick Actions */}
            {chatMessages.length === 1 && (
              <div className="px-4 pb-2">
                <div className="flex flex-wrap gap-2">
                  {quickActions.map((action) => (
                    <button
                      key={action}
                      onClick={() => handleQuickAction(action)}
                      className="px-3 py-1.5 bg-slate-700/50 hover:bg-slate-700 text-slate-300 text-sm rounded-full transition-colors"
                    >
                      {action}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input */}
            <div className="p-4 border-t border-slate-700/50">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  placeholder="Ask about closing schools..."
                  className="flex-1 bg-slate-800/50 text-white placeholder-slate-500 rounded-lg px-4 py-2 border border-slate-700/50 focus:outline-none focus:border-blue-500 transition-colors"
                />
                <button
                  onClick={handleSendMessage}
                  className="bg-blue-600 hover:bg-blue-500 text-white rounded-lg px-4 py-2 transition-colors"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
