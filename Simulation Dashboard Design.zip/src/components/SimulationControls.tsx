import { Play, Pause, RotateCcw } from 'lucide-react';

interface SimulationControlsProps {
  day: number;
  maxDays: number;
  isPlaying: boolean;
  totalInfected: number;
  totalRecovered: number;
  totalDeaths: number;
  onPlayPause: () => void;
  onReset: () => void;
  onSimulateFromHere: () => void;
}

export function SimulationControls({
  day,
  maxDays,
  isPlaying,
  totalInfected,
  totalRecovered,
  totalDeaths,
  onPlayPause,
  onReset,
  onSimulateFromHere,
}: SimulationControlsProps) {
  return (
    <div className="absolute bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-sm border-t border-slate-700/50">
      <div className="flex items-center justify-between px-6 py-4">
        {/* Left: Stats */}
        <div className="flex items-center gap-8">
          <div className="flex flex-col">
            <span className="text-slate-400 text-xs uppercase tracking-wider">Total Infected</span>
            <span className="text-red-400">{totalInfected.toLocaleString()}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-slate-400 text-xs uppercase tracking-wider">Recovered</span>
            <span className="text-green-400">{totalRecovered.toLocaleString()}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-slate-400 text-xs uppercase tracking-wider">Deaths</span>
            <span className="text-slate-300">{totalDeaths.toLocaleString()}</span>
          </div>
        </div>

        {/* Center: Playback Controls */}
        <div className="flex items-center gap-4">
          <button
            onClick={onReset}
            className="p-2 hover:bg-slate-800 rounded-lg transition-colors"
            title="Reset Simulation"
          >
            <RotateCcw className="w-5 h-5 text-slate-400 hover:text-white" />
          </button>

          <button
            onClick={onPlayPause}
            className="bg-blue-600 hover:bg-blue-500 p-3 rounded-full transition-colors"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-6 h-6 text-white" />
            ) : (
              <Play className="w-6 h-6 text-white ml-0.5" />
            )}
          </button>

          <div className="flex flex-col items-center min-w-[120px]">
            <span className="text-slate-400 text-xs uppercase tracking-wider">Day Simulation</span>
            <span className="text-white">
              {day} / {maxDays}
            </span>
          </div>

          <div className="w-64 h-2 bg-slate-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500 transition-all duration-300"
              style={{ width: `${(day / maxDays) * 100}%` }}
            />
          </div>
        </div>

        {/* Right: Simulate Button */}
        <button
          onClick={onSimulateFromHere}
          className="px-6 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded-lg transition-colors border border-slate-600"
        >
          Simulate from Here
        </button>
      </div>
    </div>
  );
}
