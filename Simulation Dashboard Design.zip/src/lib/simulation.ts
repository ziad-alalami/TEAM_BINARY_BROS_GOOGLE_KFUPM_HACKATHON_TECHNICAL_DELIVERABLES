import { District, RiskLevel, Alert, SimulationParameters, SimulationState } from '../types/simulation';

// Initial districts data for Saudi Arabia cities
export const initialDistricts: District[] = [
  {
    id: 'riyadh-north',
    name: 'Riyadh North',
    position: { x: 630, y: 260 }, // Riyadh area - center-east
    riskLevel: 'high',
    infectionRate: 12.5,
    population: 340000,
    viralityScore: 0.85,
    status: 'Hospital capacity reaching critical levels.',
    susceptible: 297500,
    exposed: 8500,
    infected: 42500,
    recovered: 0,
    deaths: 0,
  },
  {
    id: 'riyadh-west',
    name: 'Riyadh West',
    position: { x: 600, y: 280 }, // West of Riyadh
    riskLevel: 'emerging',
    infectionRate: 8.3,
    population: 280000,
    viralityScore: 0.62,
    status: 'Rising trend detected in last 48 hours.',
    susceptible: 256760,
    exposed: 5600,
    infected: 23240,
    recovered: 0,
    deaths: 0,
  },
  {
    id: 'al-olaya',
    name: 'Al-Olaya',
    position: { x: 640, y: 290 }, // Central Riyadh district
    riskLevel: 'emerging',
    infectionRate: 6.8,
    population: 195000,
    viralityScore: 0.54,
    status: 'New cluster detected in commercial zone.',
    susceptible: 181740,
    exposed: 3900,
    infected: 13260,
    recovered: 0,
    deaths: 0,
  },
  {
    id: 'jeddah-central',
    name: 'Jeddah',
    position: { x: 200, y: 380 }, // West coast - Red Sea
    riskLevel: 'stable',
    infectionRate: 4.2,
    population: 420000,
    viralityScore: 0.38,
    status: 'Controlled spread, monitoring ongoing.',
    susceptible: 402360,
    exposed: 8400,
    infected: 17640,
    recovered: 0,
    deaths: 0,
  },
  {
    id: 'madinah',
    name: 'Madinah',
    position: { x: 280, y: 270 }, // West-central area
    riskLevel: 'high',
    infectionRate: 11.2,
    population: 310000,
    viralityScore: 0.78,
    status: 'Multiple clusters identified.',
    susceptible: 275280,
    exposed: 7750,
    infected: 34720,
    recovered: 0,
    deaths: 0,
  },
  {
    id: 'eastern-province',
    name: 'Dammam',
    position: { x: 850, y: 200 }, // East coast - Persian Gulf
    riskLevel: 'low',
    infectionRate: 2.8,
    population: 380000,
    viralityScore: 0.22,
    status: 'Low transmission, preventive measures active.',
    susceptible: 369360,
    exposed: 3800,
    infected: 10640,
    recovered: 0,
    deaths: 0,
  },
];

export const getRiskColor = (level: RiskLevel): string => {
  switch (level) {
    case 'low':
      return '#10b981'; // green
    case 'stable':
      return '#3b82f6'; // blue
    case 'emerging':
      return '#f59e0b'; // yellow
    case 'high':
      return '#ef4444'; // red
    default:
      return '#6b7280';
  }
};

export const calculateRiskLevel = (infectionRate: number): RiskLevel => {
  if (infectionRate < 3) return 'low';
  if (infectionRate < 6) return 'stable';
  if (infectionRate < 10) return 'emerging';
  return 'high';
};

// SEIR Model Implementation
export const simulateDay = (
  districts: District[],
  parameters: SimulationParameters,
  day: number
): District[] => {
  return districts.map((district) => {
    const { susceptible, exposed, infected, recovered, deaths, population } = district;
    
    // Apply policy modifiers to R0
    let effectiveR0 = parameters.r0;
    if (parameters.cityLockdown) effectiveR0 *= 0.4;
    if (parameters.maskMandate) effectiveR0 *= 0.7;
    if (parameters.travelReduction) effectiveR0 *= 0.6;
    if (parameters.schoolClosure) effectiveR0 *= 0.8;
    if (parameters.remoteWork) effectiveR0 *= 0.75;
    
    // SEIR parameters
    const beta = effectiveR0 / 7; // Transmission rate
    const sigma = 1 / 5.2; // Incubation rate (5.2 days avg)
    const gamma = 1 / 7; // Recovery rate (7 days avg)
    const mu = 0.002; // Death rate
    
    // Calculate changes
    const newExposed = (beta * susceptible * infected) / population;
    const newInfected = sigma * exposed;
    const newRecovered = gamma * infected * (1 - mu);
    const newDeaths = gamma * infected * mu;
    
    // Update compartments
    const newSusceptible = Math.max(0, susceptible - newExposed);
    const newExposedTotal = Math.max(0, exposed + newExposed - newInfected);
    const newInfectedTotal = Math.max(0, infected + newInfected - newRecovered - newDeaths);
    const newRecoveredTotal = recovered + newRecovered;
    const newDeathsTotal = deaths + newDeaths;
    
    const newInfectionRate = (newInfectedTotal / population) * 100;
    const newRiskLevel = calculateRiskLevel(newInfectionRate);
    const newViralityScore = Math.min(1, (newInfectionRate / 15) * effectiveR0 / 3);
    
    // Update status message
    let status = district.status;
    if (newInfectionRate > district.infectionRate * 1.2) {
      status = 'Rapid increase in infection rate detected.';
    } else if (newInfectionRate < district.infectionRate * 0.8) {
      status = 'Infection rate declining, interventions effective.';
    } else if (newRiskLevel === 'high') {
      status = 'Hospital capacity reaching critical levels.';
    }
    
    return {
      ...district,
      susceptible: newSusceptible,
      exposed: newExposedTotal,
      infected: newInfectedTotal,
      recovered: newRecoveredTotal,
      deaths: newDeathsTotal,
      infectionRate: newInfectionRate,
      riskLevel: newRiskLevel,
      viralityScore: newViralityScore,
      status,
    };
  });
};

export const generateAlerts = (
  districts: District[],
  parameters: SimulationParameters,
  day: number
): Alert[] => {
  const alerts: Alert[] = [];
  
  // Check for new clusters
  districts.forEach((district) => {
    if (district.riskLevel === 'emerging' || district.riskLevel === 'high') {
      if (Math.random() > 0.7) {
        alerts.push({
          id: `cluster-${district.id}-${day}`,
          type: 'cluster',
          message: `New cluster detected in ${district.name} district.`,
          severity: district.riskLevel === 'high' ? 'critical' : 'warning',
          timestamp: Date.now(),
        });
      }
    }
  });
  
  // Check mobility
  if (!parameters.cityLockdown && !parameters.travelReduction) {
    alerts.push({
      id: `mobility-${day}`,
      type: 'mobility',
      message: 'Mobility remains high.',
      severity: 'warning',
      timestamp: Date.now(),
    });
  }
  
  // Check R0
  if (parameters.r0 > 2.5) {
    alerts.push({
      id: `r0-${day}`,
      type: 'r0',
      message: `R0 spiked to ${parameters.r0.toFixed(1)} in Eastern Province.`,
      severity: 'critical',
      timestamp: Date.now(),
    });
  }
  
  // Check hospital capacity
  districts.forEach((district) => {
    if (district.infectionRate > 10) {
      alerts.push({
        id: `capacity-${district.id}-${day}`,
        type: 'capacity',
        message: `${district.name}: Hospital capacity at ${Math.round((district.infectionRate / 15) * 100)}%.`,
        severity: 'critical',
        timestamp: Date.now(),
      });
    }
  });
  
  return alerts.slice(0, 5); // Keep only top 5 most recent
};

export const getAIResponse = (message: string, state: SimulationState): string => {
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('status') || lowerMessage.includes('outbreak')) {
    const highRisk = state.districts.filter(d => d.riskLevel === 'high').length;
    const emerging = state.districts.filter(d => d.riskLevel === 'emerging').length;
    return `Current outbreak status (Day ${state.day}): ${highRisk} districts at high risk, ${emerging} with emerging threats. Total infected: ${state.totalInfected.toLocaleString()}. ${state.parameters.cityLockdown ? 'City lockdown is active.' : 'No lockdown currently in place.'}`;
  }
  
  if (lowerMessage.includes('school') || lowerMessage.includes('close')) {
    return 'Closing schools can reduce R0 by approximately 20% by limiting transmission among children and reducing overall mobility. This intervention is most effective when combined with other measures like mask mandates.';
  }
  
  if (lowerMessage.includes('lockdown')) {
    return 'A city-wide lockdown reduces R0 by 60% but has significant economic impacts. It\'s most effective when implemented early or during rapid growth phases. Consider combining with targeted measures first.';
  }
  
  if (lowerMessage.includes('r0') || lowerMessage.includes('reproduction')) {
    return `Current R0 is ${state.parameters.r0}. This means each infected person will infect ${state.parameters.r0} others on average. R0 < 1 indicates declining outbreak, R0 > 1 indicates growth. Target R0 < 1 through interventions.`;
  }
  
  if (lowerMessage.includes('forecast') || lowerMessage.includes('predict')) {
    const projectedInfected = Math.round(state.totalInfected * Math.pow(state.parameters.r0, 7));
    return `7-day forecast: With current R0 of ${state.parameters.r0}, we project approximately ${projectedInfected.toLocaleString()} total infections by Day ${state.day + 7}. Implementing interventions now can significantly alter this trajectory.`;
  }
  
  if (lowerMessage.includes('mask')) {
    return 'Mask mandates reduce transmission by approximately 30%. They are cost-effective and have minimal economic impact. Most effective in high-density areas and when compliance is above 70%.';
  }
  
  return 'I can help you understand the outbreak status, explain interventions (lockdown, masks, school closures), analyze R0, and provide forecasts. What would you like to know?';
};

export const initialState: SimulationState = {
  day: 1,
  totalInfected: 0,
  totalRecovered: 0,
  totalDeaths: 0,
  districts: initialDistricts,
  alerts: [
    {
      id: 'initial-1',
      type: 'cluster',
      message: 'New cluster detected in Al-Olaya district.',
      severity: 'warning',
      timestamp: Date.now(),
    },
    {
      id: 'initial-2',
      type: 'mobility',
      message: 'Mobility remains high.',
      severity: 'warning',
      timestamp: Date.now(),
    },
    {
      id: 'initial-3',
      type: 'r0',
      message: 'R0 spiked to 2.8 in Eastern Province.',
      severity: 'critical',
      timestamp: Date.now(),
    },
  ],
  isPlaying: false,
  parameters: {
    r0: 2.5,
    cityLockdown: false,
    maskMandate: false,
    travelReduction: false,
    schoolClosure: false,
    remoteWork: false,
  },
};