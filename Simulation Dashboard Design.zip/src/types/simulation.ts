// Core simulation types
export type RiskLevel = 'low' | 'stable' | 'emerging' | 'high';

export interface District {
  id: string;
  name: string;
  position: { x: number; y: number };
  riskLevel: RiskLevel;
  infectionRate: number;
  population: number;
  viralityScore: number;
  status: string;
  susceptible: number;
  exposed: number;
  infected: number;
  recovered: number;
  deaths: number;
}

export interface Alert {
  id: string;
  type: 'cluster' | 'mobility' | 'r0' | 'capacity';
  message: string;
  severity: 'warning' | 'critical' | 'info';
  timestamp: number;
}

export interface SimulationParameters {
  r0: number;
  cityLockdown: boolean;
  maskMandate: boolean;
  travelReduction: boolean;
  schoolClosure: boolean;
  remoteWork: boolean;
}

export interface SimulationState {
  day: number;
  totalInfected: number;
  totalRecovered: number;
  totalDeaths: number;
  districts: District[];
  alerts: Alert[];
  isPlaying: boolean;
  parameters: SimulationParameters;
}

export interface MobilityMatrix {
  [fromDistrict: string]: {
    [toDistrict: string]: number;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}
